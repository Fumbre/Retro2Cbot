#include "mazeController.h"

MazeController::MazeController(int baseSpeed, int turnSpeed)
    : baseSpeed(baseSpeed), turnSpeed(turnSpeed) {}

MotorCommand MazeController::execute(MazeMove move) {

    switch(move) {
        case TURN_LEFT:
            return { -turnSpeed, turnSpeed };

        case TURN_RIGHT:
            return { turnSpeed, -turnSpeed };

        case UTURN:
            return { turnSpeed, -turnSpeed };

        default:
            return { baseSpeed, baseSpeed };
    }
}
