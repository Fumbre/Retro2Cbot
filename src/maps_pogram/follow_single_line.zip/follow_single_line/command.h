#pragma once

struct MotorCommand {
    int left;
    int right;
};
