#include "LineMazeLogic.h"

MazeLogic::MazeLogic(TurnPreference pref)
    : pref(pref) {}

MazeMove MazeLogic::decide(LineState state) {

    if (state == ALL_WHITE)
        return UTURN;

    if (state == ALL_BLACK)
        return CROSSING;

    if (state == LEFT_TURN && pref == LEFT_FIRST)
        return TURN_LEFT;

    if (state == RIGHT_TURN && pref == RIGHT_FIRST)
        return TURN_RIGHT;

    return GO_FORWARD;
}
