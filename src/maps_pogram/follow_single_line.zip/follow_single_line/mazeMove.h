#pragma once

enum MazeMove {
    GO_FORWARD,
    TURN_LEFT,
    TURN_RIGHT,
    UTURN,
    CROSSING
};
